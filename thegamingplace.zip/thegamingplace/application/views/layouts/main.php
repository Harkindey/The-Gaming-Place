


<?php $this->load->view('layouts/includes/header'); ?>

    <!--Display Main Content-->
    <?php $this->load->view($main_content); ?>

<?php $this->load->view('layouts/includes/footer'); ?>
